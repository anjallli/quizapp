package com.gaara.quiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gaara.quiz.databinding.ActivityCategoriesBinding

class CategoriesActivity : AppCompatActivity() {

    lateinit var categoriesBinding: ActivityCategoriesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        categoriesBinding = ActivityCategoriesBinding.inflate(layoutInflater)
        val view = categoriesBinding.root
        setContentView(view)

        categoriesBinding.toolbar.title = "Categories"

        categoriesBinding.txtHistory.setOnClickListener {
            val intent = Intent(this,HistoryActivity::class.java)
            startActivity(intent)
        }

        categoriesBinding.txtGk.setOnClickListener {
            val intent = Intent(this,GkActivity::class.java)
            startActivity(intent)
        }

        categoriesBinding.txtSports.setOnClickListener {
            val intent = Intent(this,SportsActivity::class.java)
            startActivity(intent)
        }

        categoriesBinding.txtTechnology.setOnClickListener {
            val intent = Intent(this,TechActivity::class.java)
            startActivity(intent)
        }
    }
}