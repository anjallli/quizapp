package com.gaara.quiz.util

import android.content.Context
import android.net.*
import com.google.firebase.database.ValueEventListener

class ConnectionManager {

    fun checkConnectivity(context: Context) : Boolean
    {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val activeNetwork : NetworkInfo? = connectivityManager.activeNetworkInfo

        return if (activeNetwork?.isConnected!=null) {
            activeNetwork.isConnected
        } else {
            false
        }
    }
}