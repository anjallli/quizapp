package com.gaara.quiz

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import com.gaara.quiz.databinding.ActivityLoginBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlin.math.log

class LoginActivity : AppCompatActivity() {

    lateinit var loginBinding : ActivityLoginBinding

    var auth : FirebaseAuth = FirebaseAuth.getInstance()

    lateinit var googleSignInClient : GoogleSignInClient

    lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loginBinding = ActivityLoginBinding.inflate(layoutInflater)
        val view = loginBinding.root
        setContentView(view)

        val txtGoogle = loginBinding.btnGoogle.getChildAt(0) as TextView
        txtGoogle.text = "Sign In with Google"
        txtGoogle.setTextColor(Color.BLACK)
        txtGoogle.textSize = 15F

        registerActivityForGoogleSignIn()

        loginBinding.btnSignIn.setOnClickListener {

            val email = loginBinding.etEmail.text.toString()
            val password = loginBinding.etPassword.text.toString()

            if (email == "" && password == "")
            {
                Toast.makeText(applicationContext,"Please enter the details", Toast.LENGTH_SHORT).show()
            }
            else if (email=="")
            {
                Toast.makeText(applicationContext,"Please enter your email", Toast.LENGTH_SHORT).show()
                loginBinding.etEmail.setText("")
            }
            else if(password == "")
            {
                Toast.makeText(applicationContext,"Please enter your password", Toast.LENGTH_SHORT).show()
                loginBinding.etPassword.setText("")
            }
            else
            {
                signInUser(email, password)
            }
        }

        loginBinding.txtSignUp.setOnClickListener {
            val intent = Intent(this@LoginActivity,SignUpActivity::class.java)
            startActivity(intent)
            loginBinding.etEmail.setText("")
            loginBinding.etPassword.setText("")
        }

        loginBinding.btnForgot.setOnClickListener {
            val intent = Intent(this@LoginActivity,ForgotActivity::class.java)
            startActivity(intent)
            loginBinding.etPassword.setText("")
        }

        loginBinding.btnGoogle.setOnClickListener {
            signInGoogle()
        }
    }

    fun signInUser(email:String, password:String)
    {
        loginBinding.progressLayout.isVisible = true
        loginBinding.progressBar.isVisible = true

        auth.signInWithEmailAndPassword(email,password).addOnCompleteListener { task->
            if (task.isSuccessful)
            {
                Toast.makeText(applicationContext,"Welcome to Quiz",Toast.LENGTH_SHORT).show()
                val intent = Intent(this@LoginActivity,MainActivity::class.java)
                startActivity(intent)
                finish()
            }
            else
            {
                Toast.makeText(applicationContext,task.exception?.localizedMessage,Toast.LENGTH_SHORT).show()
                loginBinding.progressLayout.isVisible = false
                loginBinding.progressBar.isVisible = false
            }
        }
    }

    override fun onStart() {
        super.onStart()

        val user = auth.currentUser
        if (user!=null)
        {
            val intent = Intent(this@LoginActivity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun signInGoogle()
    {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("407158369129-trs1tq947blts26dda8ngbsucmm1a9bu.apps.googleusercontent.com")
            .requestEmail().build()

        googleSignInClient = GoogleSignIn.getClient(this,gso)

        signInIntent()
    }

    private fun signInIntent()
    {
        val signInIntent : Intent = googleSignInClient.signInIntent
        activityResultLauncher.launch(signInIntent)
    }

    private fun registerActivityForGoogleSignIn()
    {
        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult(),
            ActivityResultCallback { result ->

                val resultCode = result.resultCode
                val data = result.data

                if (resultCode == RESULT_OK && data!=null)
                {
                    val task : Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
                    firebaseSignInAccount(task)
                }
            })
    }

    private fun firebaseSignInAccount(task: Task<GoogleSignInAccount>)
    {
        try
        {
            val account : GoogleSignInAccount = task.getResult(ApiException::class.java)
            Toast.makeText(applicationContext,"Welcome to Quiz",Toast.LENGTH_SHORT).show()
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
            finish()
            firebaseGoogleAccount(account)
        }
        catch (e:ApiException)
        {
            Toast.makeText(applicationContext, e.localizedMessage?.toString(),Toast.LENGTH_SHORT).show()
        }
    }

    private fun firebaseGoogleAccount(account: GoogleSignInAccount)
    {
        val authCredential = GoogleAuthProvider.getCredential(account.idToken,null)
        auth.signInWithCredential(authCredential)
    }
}
