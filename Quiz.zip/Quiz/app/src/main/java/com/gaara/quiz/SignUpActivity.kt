package com.gaara.quiz

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.view.isVisible
import com.gaara.quiz.databinding.ActivitySignUpBinding
import com.google.firebase.auth.FirebaseAuth

class SignUpActivity : AppCompatActivity() {

    lateinit var signUpBinding : ActivitySignUpBinding

    var auth : FirebaseAuth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        signUpBinding = ActivitySignUpBinding.inflate(layoutInflater)
        val view = signUpBinding.root
        setContentView(view)

        signUpBinding.toolbar.title = "Sign Up"

        signUpBinding.btnSignUp.setOnClickListener {
            val email = signUpBinding.etEmail.text.toString()
            val password = signUpBinding.etPassword.text.toString()

            if (email == "" && password == "")
            {
                Toast.makeText(applicationContext,"Please enter the details",Toast.LENGTH_SHORT).show()
            }
            else if (email=="")
            {
                Toast.makeText(applicationContext,"Please enter your email",Toast.LENGTH_SHORT).show()
                signUpBinding.etEmail.setText("")
            }
            else if(password == "")
            {
                Toast.makeText(applicationContext,"Please enter your password",Toast.LENGTH_SHORT).show()
                signUpBinding.etPassword.setText("")
            }
            else
            {
                signUp(email,password)
            }
        }
    }

    fun signUp(email:String, password :String){

        signUpBinding.progressLayout.isVisible = true
        signUpBinding.progressBar.isVisible = true

        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener { task->
            if (task.isSuccessful)
            {
                Toast.makeText(applicationContext,"Your account has been created",Toast.LENGTH_SHORT).show()
                finish()
            }
            else
            {
                Toast.makeText(applicationContext,task.exception?.localizedMessage.toString(),Toast.LENGTH_SHORT).show()
                signUpBinding.progressLayout.isVisible = false
                signUpBinding.progressBar.isVisible = false
            }
        }

    }
}