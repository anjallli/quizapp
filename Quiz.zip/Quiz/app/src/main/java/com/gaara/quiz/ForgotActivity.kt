package com.gaara.quiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.gaara.quiz.databinding.ActivityForgotBinding
import com.google.firebase.auth.FirebaseAuth

class ForgotActivity : AppCompatActivity() {

    lateinit var forgotBinding : ActivityForgotBinding

    var auth : FirebaseAuth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        forgotBinding = ActivityForgotBinding.inflate(layoutInflater)
        val view = forgotBinding.root
        setContentView(view)

        forgotBinding.toolbar.title = "Forgot Password"

        forgotBinding.btnReset.setOnClickListener {

            val email = forgotBinding.etEmail.text.toString()

            if (email == "")
            {
                Toast.makeText(applicationContext,"Please enter your registered email",Toast.LENGTH_SHORT).show()
            }
            else
            {
                resetPassword(email)
            }
        }
    }

    fun resetPassword(email:String)
    {
        auth.sendPasswordResetEmail(email).addOnCompleteListener { task->

            if (task.isSuccessful)
            {
                Toast.makeText(applicationContext,"Password Reset Link sent to your email successfully",Toast.LENGTH_LONG).show()
                finish()
            }
            else
            {
                Toast.makeText(applicationContext,task.exception?.localizedMessage.toString(),Toast.LENGTH_SHORT).show()
            }
        }
    }
}