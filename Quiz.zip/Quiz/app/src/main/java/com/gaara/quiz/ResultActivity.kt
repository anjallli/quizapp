package com.gaara.quiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.gaara.quiz.databinding.ActivityResultBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ResultActivity : AppCompatActivity() {

    lateinit var resultBinding: ActivityResultBinding

    private val database : FirebaseDatabase = FirebaseDatabase.getInstance()
    val reference : DatabaseReference = database.reference

    private val auth = FirebaseAuth.getInstance()
    val user = auth.currentUser

    var correctAnswer = ""
    var finalScore = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        resultBinding = ActivityResultBinding.inflate(layoutInflater)
        val view = resultBinding.root
        setContentView(view)

        val category = intent.getStringExtra("Category")
        resultBinding.txtcategory.text = category

        reference.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {

                if (intent!=null)
                {
                    val id = intent.getStringExtra("id")
                    if (id.equals("From_Activity_MIH"))
                    {
                        user?.let {

                            val userUid = it.uid

                            correctAnswer = snapshot.child("MIH_Scores").child(userUid).child("correct").value.toString()
                            val finalNum = correctAnswer.toInt()
                            finalScore = (finalNum*4).toString()
                            resultBinding.txtFinalScore.text = finalScore
                            resultBinding.txtCorrectAnswer.text = correctAnswer
                        }
                    }
                    if (id.equals("From_Activity_GK"))
                    {
                        user?.let {

                            val userUid = it.uid

                            correctAnswer = snapshot.child("GK_Scores").child(userUid).child("correct").value.toString()
                            val finalNum = correctAnswer.toInt()
                            finalScore = (finalNum*4).toString()

                            resultBinding.txtFinalScore.text = finalScore
                            resultBinding.txtCorrectAnswer.text = correctAnswer

                        }
                    }
                    if (id.equals("From_Activity_Sports"))
                    {
                        user?.let {

                            val userUid = it.uid

                            correctAnswer = snapshot.child("Sports_Scores").child(userUid).child("correct").value.toString()
                            val finalNum = correctAnswer.toInt()
                            finalScore = (finalNum*4).toString()

                            resultBinding.txtFinalScore.text = finalScore
                            resultBinding.txtCorrectAnswer.text = correctAnswer

                        }
                    }
                    if (id.equals("From_Activity_Tech"))
                    {
                        user?.let {

                            val userUid = it.uid

                            correctAnswer = snapshot.child("Tech_Scores").child(userUid).child("correct").value.toString()
                            val finalNum = correctAnswer.toInt()
                            finalScore = (finalNum*4).toString()

                            resultBinding.txtFinalScore.text = finalScore
                            resultBinding.txtCorrectAnswer.text = correctAnswer

                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(applicationContext,error.message,Toast.LENGTH_SHORT).show()
            }
        })

        resultBinding.btnPlayAgain.setOnClickListener {
            val intent = Intent(this@ResultActivity,MainActivity::class.java)
            startActivity(intent)
            finishAffinity()
        }

        resultBinding.btnExit.setOnClickListener {
            val dialog = AlertDialog.Builder(this)
            dialog.setTitle("Exit")
            dialog.setMessage("Do you want to exit?")
            dialog.setNegativeButton("No"){text,listener->
                //user clicked No
            }
            dialog.setPositiveButton("Yes"){text,listener->
                finishAffinity()
            }.create().show()
        }
    }
}