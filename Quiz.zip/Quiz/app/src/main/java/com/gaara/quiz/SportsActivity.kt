package com.gaara.quiz

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import com.gaara.quiz.databinding.ActivitySportsBinding
import com.gaara.quiz.util.ConnectionManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.*

class SportsActivity : AppCompatActivity() {

    lateinit var sportsBinding: ActivitySportsBinding

    val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    val reference: DatabaseReference = database.reference.child("Sports")

    val auth = FirebaseAuth.getInstance()
    val user = auth.currentUser
    val scoreReference = database.reference

    var question = ""
    var answerA = ""
    var answerB = ""
    var answerC = ""
    var answerD = ""

    var questionCount = 0
    var questionNumber = 1

    var userAnswer = ""
    var correctAnswer = ""
    var correctView = 0
    var wrongView = 0

    var pressedTime: Long = 0

    lateinit var timer: CountDownTimer
    private val startTimerInMillis: Long = 30000
    var timerLeftInMillis: Long = startTimerInMillis

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sportsBinding = ActivitySportsBinding.inflate(layoutInflater)
        val view = sportsBinding.root
        setContentView(view)

        sportsBinding.toolbar.title = "Sports"

        if (!ConnectionManager().checkConnectivity(this)) {
            Toast.makeText(
                applicationContext,
                "No Connection, Please Try Again",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            gameLogic()
        }

        sportsBinding.answerA.setOnClickListener {

            pauseTimer()

            userAnswer = "a"
            if (userAnswer == correctAnswer) {
                sportsBinding.answerA.setTextColor(Color.GREEN)
                correctView++
                sportsBinding.txtCorrect.text = correctView.toString()
            } else {
                sportsBinding.answerA.setTextColor(Color.RED)
                wrongView++
                sportsBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        sportsBinding.answerB.setOnClickListener {

            pauseTimer()

            userAnswer = "b"
            if (correctAnswer == userAnswer) {
                sportsBinding.answerB.setTextColor(Color.GREEN)
                correctView++
                sportsBinding.txtCorrect.text = correctView.toString()
            } else {
                sportsBinding.answerB.setTextColor(Color.RED)
                wrongView++
                sportsBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        sportsBinding.answerC.setOnClickListener {

            pauseTimer()

            userAnswer = "c"
            if (correctAnswer == userAnswer) {
                sportsBinding.answerC.setTextColor(Color.GREEN)
                correctView++
                sportsBinding.txtCorrect.text = correctView.toString()
            } else {
                sportsBinding.answerC.setTextColor(Color.RED)
                wrongView++
                sportsBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        sportsBinding.answerD.setOnClickListener {

            pauseTimer()

            userAnswer = "d"
            if (correctAnswer == userAnswer) {
                sportsBinding.answerD.setTextColor(Color.GREEN)
                correctView++
                sportsBinding.txtCorrect.text = correctView.toString()
            } else {
                sportsBinding.answerD.setTextColor(Color.RED)
                wrongView++
                sportsBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        sportsBinding.btnNext.setOnClickListener {
            if (!ConnectionManager().checkConnectivity(this)) {
                Toast.makeText(
                    applicationContext,
                    "No Connection, Please Try Again",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                resetTimer()
                gameLogic()
                restoreOptions()
            }
        }

        sportsBinding.btnFinish.setOnClickListener {
            val dialog = AlertDialog.Builder(this)
            dialog.setCancelable(false)
            dialog.setTitle("Quit")
            dialog.setMessage("Are you sure you want to quit?")
            dialog.setNegativeButton("No") { text, listener ->
                //user clicked on NO
            }
            dialog.setPositiveButton("Yes") { text, listener ->
                if (!ConnectionManager().checkConnectivity(this)) {
                    Toast.makeText(
                        applicationContext,
                        "No Connection, Please Try Again",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    sportsBinding.progressBar.isVisible = true
                    sendScore()
                    sportsBinding.progressBar.isVisible = false
                }
            }.create().show()

            pauseTimer()
        }
    }

    private fun gameLogic()
    {
        reference.addValueEventListener(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                questionCount = snapshot.childrenCount.toInt()

                if (questionNumber<=questionCount)
                {
                    question = snapshot.child(questionNumber.toString()).child("q").value.toString()
                    answerA = snapshot.child(questionNumber.toString()).child("a").value.toString()
                    answerB = snapshot.child(questionNumber.toString()).child("b").value.toString()
                    answerC = snapshot.child(questionNumber.toString()).child("c").value.toString()
                    answerD = snapshot.child(questionNumber.toString()).child("d").value.toString()
                    correctAnswer = snapshot.child(questionNumber.toString()).child("answer").value.toString()

                    sportsBinding.txtQuestion.text = question
                    sportsBinding.answerA.text = answerA
                    sportsBinding.answerB.text = answerB
                    sportsBinding.answerC.text = answerC
                    sportsBinding.answerD.text = answerD

                    sportsBinding.progressBar.isInvisible = true
                    sportsBinding.scoreLayout.isVisible = true
                    sportsBinding.questionLayout.isVisible = true
                    sportsBinding.btnLayout.isVisible = true
                    startTimer()
                }
                else
                {
                    dialogEnd()
                    disableOptionsClick()
                }

                questionNumber++

            }

            override fun onCancelled(e: DatabaseError) {
                Toast.makeText(applicationContext, e.message, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun findAnswer()
    {
        when(correctAnswer){
            "a" -> sportsBinding.answerA.setTextColor(Color.GREEN)
            "b" -> sportsBinding.answerB.setTextColor(Color.GREEN)
            "c" -> sportsBinding.answerC.setTextColor(Color.GREEN)
            "d" -> sportsBinding.answerD.setTextColor(Color.GREEN)
        }
    }

    private fun disableOptionsClick()
    {
        sportsBinding.answerA.isClickable = false
        sportsBinding.answerB.isClickable = false
        sportsBinding.answerC.isClickable = false
        sportsBinding.answerD.isClickable = false

    }

    private fun restoreOptions()
    {
        sportsBinding.answerA.setTextColor(Color.WHITE)
        sportsBinding.answerB.setTextColor(Color.WHITE)
        sportsBinding.answerC.setTextColor(Color.WHITE)
        sportsBinding.answerD.setTextColor(Color.WHITE)

        sportsBinding.answerA.isClickable = true
        sportsBinding.answerB.isClickable = true
        sportsBinding.answerC.isClickable = true
        sportsBinding.answerD.isClickable = true
    }

    fun startTimer()
    {
        timer = object : CountDownTimer(timerLeftInMillis,1000){
            override fun onTick(millisUntilFinished: Long) {
                timerLeftInMillis = millisUntilFinished
                updateTimeText()
            }

            override fun onFinish() {
                if (!ConnectionManager().checkConnectivity(this@SportsActivity))
                {
                    Toast.makeText(applicationContext,"Time is Up", Toast.LENGTH_SHORT).show()
                    disableOptionsClick()
                }
                else
                {
                    Toast.makeText(applicationContext,"Time is Up", Toast.LENGTH_SHORT).show()
                    resetTimer()
                    //updateTimeText()
                    //historyBinding.txtQuestion.text = "Time is up:(\nCLick NEXT to continue"
                    gameLogic()
                    restoreOptions()
                }
            }
        }.start()
    }

    fun updateTimeText()
    {
        val remainingTime = timerLeftInMillis/1000
        sportsBinding.txtTimer.text = String.format(Locale.getDefault(),"%02d",remainingTime)
    }

    fun pauseTimer()
    {
        timer.cancel()
    }

    fun resetTimer()
    {
        pauseTimer()
        timerLeftInMillis = startTimerInMillis
        updateTimeText()
    }

    private fun sendScore()
    {
        user?.let {
            val userUid = it.uid
            scoreReference.child("Sports_Scores").child(userUid).child("correct").setValue(correctView)
            scoreReference.child("Sports_Scores").child(userUid).child("wrong").setValue(wrongView).addOnCompleteListener {

                val intent = Intent(this@SportsActivity,ResultActivity::class.java)
                intent.putExtra("id","From_Activity_Sports")
                intent.putExtra("Category","Sports")
                startActivity(intent)
                finish()

            }
        }
    }

    fun dialogEnd()
    {
        val dialog = AlertDialog.Builder(this@SportsActivity)
        dialog.setTitle("The End")
        dialog.setMessage("You have come to the end of questions.")
        dialog.setCancelable(false)
        dialog.setPositiveButton("View Results"){ text,listener ->
            if (!ConnectionManager().checkConnectivity(this))
            {
                Toast.makeText(applicationContext,"No Connection, Please Try Again", Toast.LENGTH_SHORT).show()
            }
            else
            {
                sportsBinding.progressBar.isVisible = true
                sendScore()
                sportsBinding.progressBar.isVisible = false
            }
        }

        dialog.setNegativeButton("Play Again"){text,listener->
            val intent = Intent(this@SportsActivity,CategoriesActivity::class.java)
            startActivity(intent)
            finish()
        }
        dialog.create().show()
    }

    override fun onBackPressed() {
        if (pressedTime + 2000 > System.currentTimeMillis())
        {
            super.onBackPressed()
            pauseTimer()
            finish()
        }
        else
        {
            Toast.makeText(applicationContext,"Press back again to exit", Toast.LENGTH_SHORT).show()
        }
        pressedTime = System.currentTimeMillis()
    }
}