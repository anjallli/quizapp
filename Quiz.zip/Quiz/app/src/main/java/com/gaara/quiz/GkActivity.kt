package com.gaara.quiz

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import com.gaara.quiz.databinding.ActivityGkBinding
import com.gaara.quiz.util.ConnectionManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.Locale

class GkActivity : AppCompatActivity() {

    lateinit var gkBinding : ActivityGkBinding

    val database : FirebaseDatabase = FirebaseDatabase.getInstance()
    val reference : DatabaseReference = database.reference.child("World GK")

    val auth = FirebaseAuth.getInstance()
    val user = auth.currentUser
    val scoreReference = database.reference

    var question = ""
    var answerA = ""
    var answerB = ""
    var answerC = ""
    var answerD = ""

    var questionCount = 0
    var questionNumber = 1

    var userAnswer = ""
    var correctAnswer = ""
    var correctView = 0
    var wrongView = 0

    var pressedTime : Long = 0

    lateinit var timer : CountDownTimer
    private val startTimerInMillis : Long = 30000
    var timerLeftInMillis : Long = startTimerInMillis

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gkBinding=ActivityGkBinding.inflate(layoutInflater)
        val view = gkBinding.root
        setContentView(view)

        gkBinding.toolbar.title = "World GK"

        if (!ConnectionManager().checkConnectivity(this))
        {
            Toast.makeText(applicationContext,"No Connection, Please Try Again", Toast.LENGTH_SHORT).show()
        }
        else
        {
            gameLogic()
        }

        gkBinding.answerA.setOnClickListener {

            pauseTimer()

            userAnswer = "a"
            if (userAnswer==correctAnswer)
            {
                gkBinding.answerA.setTextColor(Color.GREEN)
                correctView++
                gkBinding.txtCorrect.text = correctView.toString()
            }
            else
            {
                gkBinding.answerA.setTextColor(Color.RED)
                wrongView++
                gkBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        gkBinding.answerB.setOnClickListener {

            pauseTimer()

            userAnswer = "b"
            if (correctAnswer == userAnswer)
            {
                gkBinding.answerB.setTextColor(Color.GREEN)
                correctView++
                gkBinding.txtCorrect.text = correctView.toString()
            }
            else
            {
                gkBinding.answerB.setTextColor(Color.RED)
                wrongView++
                gkBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        gkBinding.answerC.setOnClickListener {

            pauseTimer()

            userAnswer = "c"
            if (correctAnswer == userAnswer)
            {
                gkBinding.answerC.setTextColor(Color.GREEN)
                correctView++
                gkBinding.txtCorrect.text = correctView.toString()
            }
            else
            {
                gkBinding.answerC.setTextColor(Color.RED)
                wrongView++
                gkBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        gkBinding.answerD.setOnClickListener {

            pauseTimer()

            userAnswer = "d"
            if (correctAnswer == userAnswer)
            {
                gkBinding.answerD.setTextColor(Color.GREEN)
                correctView++
                gkBinding.txtCorrect.text = correctView.toString()
            }
            else
            {
                gkBinding.answerD.setTextColor(Color.RED)
                wrongView++
                gkBinding.txtWrong.text = wrongView.toString()
                findAnswer()
            }
            disableOptionsClick()
        }

        gkBinding.btnNext.setOnClickListener {
            if (!ConnectionManager().checkConnectivity(this))
            {
                Toast.makeText(applicationContext,"No Connection, Please Try Again", Toast.LENGTH_SHORT).show()
            }
            else
            {
                resetTimer()
                gameLogic()
                restoreOptions()
            }
        }

        gkBinding.btnFinish.setOnClickListener {
            val dialog = AlertDialog.Builder(this)
            dialog.setCancelable(false)
            dialog.setTitle("Quit")
            dialog.setMessage("Are you sure you want to quit?")
            dialog.setNegativeButton("No"){text, listener ->
                //user clicked on NO
            }
            dialog.setPositiveButton("Yes") { text, listener ->
                if (!ConnectionManager().checkConnectivity(this)) {
                    Toast.makeText(
                        applicationContext,
                        "No Connection, Please Try Again",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    gkBinding.progressBar.isVisible = true
                    sendScore()
                    gkBinding.progressBar.isVisible = false
                }
            }.create().show()

            pauseTimer()
        }
    }

    private fun gameLogic()
    {
        reference.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {

                questionCount = snapshot.childrenCount.toInt()

                if (questionNumber<=questionCount)
                {
                    question = snapshot.child(questionNumber.toString()).child("q").value.toString()
                    answerA = snapshot.child(questionNumber.toString()).child("a").value.toString()
                    answerB = snapshot.child(questionNumber.toString()).child("b").value.toString()
                    answerC = snapshot.child(questionNumber.toString()).child("c").value.toString()
                    answerD = snapshot.child(questionNumber.toString()).child("d").value.toString()
                    correctAnswer = snapshot.child(questionNumber.toString()).child("answer").value.toString()

                    gkBinding.txtQuestion.text = question
                    gkBinding.answerA.text = answerA
                    gkBinding.answerB.text = answerB
                    gkBinding.answerC.text = answerC
                    gkBinding.answerD.text = answerD

                    gkBinding.progressBar.isInvisible = true
                    gkBinding.scoreLayout.isVisible = true
                    gkBinding.questionLayout.isVisible = true
                    gkBinding.btnLayout.isVisible = true
                    startTimer()
                }
                else
                {
                    dialogEnd()
                    disableOptionsClick()
                }

                questionNumber++

            }

            override fun onCancelled(e: DatabaseError) {
                Toast.makeText(applicationContext, e.message, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun findAnswer()
    {
        when(correctAnswer){
            "a" -> gkBinding.answerA.setTextColor(Color.GREEN)
            "b" -> gkBinding.answerB.setTextColor(Color.GREEN)
            "c" -> gkBinding.answerC.setTextColor(Color.GREEN)
            "d" -> gkBinding.answerD.setTextColor(Color.GREEN)
        }
    }

    private fun disableOptionsClick()
    {
        gkBinding.answerA.isClickable = false
        gkBinding.answerB.isClickable = false
        gkBinding.answerC.isClickable = false
        gkBinding.answerD.isClickable = false

    }

    private fun restoreOptions()
    {
        gkBinding.answerA.setTextColor(Color.WHITE)
        gkBinding.answerB.setTextColor(Color.WHITE)
        gkBinding.answerC.setTextColor(Color.WHITE)
        gkBinding.answerD.setTextColor(Color.WHITE)

        gkBinding.answerA.isClickable = true
        gkBinding.answerB.isClickable = true
        gkBinding.answerC.isClickable = true
        gkBinding.answerD.isClickable = true
    }

    fun startTimer()
    {
        timer = object : CountDownTimer(timerLeftInMillis,1000)
        {
            override fun onTick(millisUntilFinished: Long) {
                timerLeftInMillis = millisUntilFinished
                updateTimeText()
            }

            override fun onFinish() {

                if (!ConnectionManager().checkConnectivity(this@GkActivity))
                {
                    Toast.makeText(applicationContext,"Time is Up", Toast.LENGTH_SHORT).show()
                    disableOptionsClick()
                }
                else
                {
                    Toast.makeText(applicationContext,"Time is Up", Toast.LENGTH_SHORT).show()
                    resetTimer()
                    //updateTimeText()
                    //historyBinding.txtQuestion.text = "Time is up:(\nCLick NEXT to continue"
                    gameLogic()
                    restoreOptions()
                }
            }
        }.start()
    }

    fun updateTimeText()
    {
        val remainingTime = timerLeftInMillis/1000
        gkBinding.txtTimer.text = String.format(Locale.getDefault(),"%02d",remainingTime)
    }

    fun pauseTimer()
    {
        timer.cancel()
    }

    fun resetTimer()
    {
        pauseTimer()
        timerLeftInMillis = startTimerInMillis
        updateTimeText()
    }

    private fun sendScore()
    {
        user?.let {
            val userUid = it.uid
            scoreReference.child("GK_Scores").child(userUid).child("correct").setValue(correctView)
            scoreReference.child("GK_Scores").child(userUid).child("wrong").setValue(wrongView).addOnCompleteListener {

                val intent = Intent(this@GkActivity,ResultActivity::class.java)
                intent.putExtra("id","From_Activity_GK")
                intent.putExtra("Category","World GK")
                startActivity(intent)
                finish()

            }
        }
    }

    fun dialogEnd()
    {
        val dialog = AlertDialog.Builder(this@GkActivity)
        dialog.setTitle("The End")
        dialog.setMessage("You have come to the end of questions.")
        dialog.setCancelable(false)
        dialog.setPositiveButton("View Results"){ text,listener ->
            if (!ConnectionManager().checkConnectivity(this))
            {
                Toast.makeText(applicationContext,"No Connection, Please Try Again", Toast.LENGTH_SHORT).show()
            }
            else
            {
                gkBinding.progressBar.isVisible = true
                sendScore()
                gkBinding.progressBar.isVisible = false
            }
        }

        dialog.setNegativeButton("Play Again"){text,listener->
            val intent = Intent(this@GkActivity,CategoriesActivity::class.java)
            startActivity(intent)
            finish()
        }
        dialog.create().show()
    }

    override fun onBackPressed() {
        if (pressedTime + 2000 > System.currentTimeMillis())
        {
            super.onBackPressed()
            pauseTimer()
            finish()
        }
        else
        {
            Toast.makeText(applicationContext,"Press back again to exit", Toast.LENGTH_SHORT).show()
        }
        pressedTime = System.currentTimeMillis()
    }
}